var monkey;
function preload() {
  monkey = loadImage("monkey_01.png");  
  
}
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
  var rec= createSprite(10,10,10,100);
  
  rec.addImage("heloo",monkey);
  
  drawSprites();
}